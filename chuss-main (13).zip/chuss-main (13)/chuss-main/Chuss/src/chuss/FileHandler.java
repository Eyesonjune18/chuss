package chuss;

//Reads from and writes to files for savegames and any other necessary file operations.

public class FileHandler {

    public static void main(String[] args) {



    }

}