package chuss;

//This class handles the main menu and the user interaction with it.

public class Menu {

    public static void main(String[] args) {



    }

    private static void getInteraction() {
        //Determines the user input from the main menu buttons
        //and calls other functions accordingly.


    }

    private static void play() {
        //Creates a new game and starts it.


    }

    private static void resume() {
        //Retrieves the most recently played save and loads it.


    }

    private static void load() {
        //Takes any game save file and loads it.


    }

}